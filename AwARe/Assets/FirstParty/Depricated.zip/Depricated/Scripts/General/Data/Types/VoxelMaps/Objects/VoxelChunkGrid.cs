namespace AwARe.Data.Objects
{
    public class VoxelChunkGridBehavior : ChunkGrid<bool> { }
}
