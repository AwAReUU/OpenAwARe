﻿using System;

using AwARe.Data;

namespace AwARe.RoomScan.VoxelMap.Logic
{
    public class VoxelCalculator : IVoxelCalculator
    {
        public void UpdateVoxelInfo(IChunkGrid<ScanInfo> scanInfo, IChunkGrid<VoxelInfo> voxelInfo)
        {
            throw new NotImplementedException();
        }
    }
}

